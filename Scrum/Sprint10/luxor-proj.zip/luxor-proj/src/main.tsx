import "./styles/globals.css";
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Analytics } from '@vercel/analytics/react'
import App from "./app/App";

const rootEl = document.getElementById('root');
if (!rootEl) {
  console.error("Root element not found!");
} else {
  createRoot(rootEl).render(
    <StrictMode>
      <App />
      <Analytics />
    </StrictMode>,
  )
}
