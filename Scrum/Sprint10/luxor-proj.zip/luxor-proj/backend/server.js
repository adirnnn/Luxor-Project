import express from "express";
import { pathToFileURL } from "node:url";
import cors from "cors";
import dotenv from "dotenv";
import { notifyOrderStatus } from './services/orderEmails.js';
import pool from './db.js';
import bcrypt from 'bcryptjs';
import { CSV_TEMPLATE, validateCsv, CsvValidationError } from './csvImport.js';
import { listSyncLogs, logSyncError } from './services/perfumSyncLog.js';
import { searchExternalPerfumes, PerfumApiError } from './services/perfumApiClient.js';
import { getKnownBrands } from './services/perfumBrands.js';
import { mapExternalPerfumeToProduct } from './services/perfumMapper.js';
import { validateMappedPerfume } from './services/perfumValidation.js';
import { buildGatewayPayload, chargeCard, PaymentGatewayError } from './services/paymentGateway.js';
import {
  getGeneralMetrics,
  getMonthlySales,
  getSalesByCategory,
  getTopProducts,
  getInventoryByCategory,
} from './services/reportMetrics.js';
import { signToken, authenticate, authorizeSelfOrRoles, requireRoles } from './services/auth.js';
import { createLoginHandler, createRegisterHandler } from './services/authHandlers.js';
import { isSafeImage, IMAGE_ERROR_MESSAGE } from './services/imageValidation.js';
import { rateLimit } from './services/rateLimit.js';
import { parseCatalogParams, buildCatalogQuery } from './services/catalogQuery.js';
import commerceRouter from './commerce.js';
import ordersRouter from './routes/orders.js';
import passwordResetRouter from './routes/passwordReset.js';
import wishlistRouter from './routes/wishlist.js';
import relatedRouter from './routes/related.js';
import productImagesRouter from './routes/productImages.js';
import orderLookupRouter from './routes/orderLookup.js';
import helmet from 'helmet';
import { requireInternalKey } from './services/internalKey.js';
import { recordSecurityEvent, getSecurityAlerts, SECURITY_EVENT_TYPES } from './services/securityEvents.js';

const SALT_ROUNDS = 12;

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// SFTWRKEY-380: Render pone un proxy delante; sin esto req.ip es la IP del proxy
// y el rate limit bloquea a todos los usuarios a la vez.
app.set("trust proxy", 1);
// Cabeceras de seguridad (HSTS, nosniff, frameguard, etc.) y sin X-Powered-By.
// SFTWRKEY-384: la API solo devuelve JSON, así que su CSP no permite cargar nada
// (hallazgos de ZAP "CSP: Wildcard Directive" y "Failure to Define Directive").
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc: ["'none'"],
      baseUri: ["'none'"],
      formAction: ["'none'"],
      frameAncestors: ["'none'"],
    },
  },
}));
app.use((_req, res, next) => {
  res.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: "2mb" }));

const ensureImportHistoryTable = () => pool.query(`
  CREATE TABLE IF NOT EXISTS product_imports (
    id SERIAL PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL,
    total_rows INTEGER NOT NULL,
    imported_rows INTEGER NOT NULL DEFAULT 0,
    rejected_rows INTEGER NOT NULL DEFAULT 0,
    errors JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
  )
`);

const saveImportHistory = async ({ fileName, totalRows, importedRows, errors }) => {
  await ensureImportHistoryTable();
  const result = await pool.query(
    `INSERT INTO product_imports (file_name, total_rows, imported_rows, rejected_rows, errors)
     VALUES ($1, $2, $3, $4, $5::jsonb)
     RETURNING id, file_name, total_rows, imported_rows, rejected_rows, errors, created_at`,
    [fileName, totalRows, importedRows, new Set(errors.map((error) => error.row)).size, JSON.stringify(errors)]
  );
  return result.rows[0];
};

// ── Productos (Desde DB) ──────────────────────────────────────────────────────
app.get("/products", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, c.nombre AS category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       ORDER BY p.created_at DESC`
    );
    const formatted = result.rows.map(p => ({
      ...p,
      notes: { salida: p.salida, corazon: p.corazon, fondo: p.fondo }
    }));
    res.json(formatted);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener productos" });
  }
});

// SFTWRKEY-424: catálogo con paginación y filtros (q, brand, category, minPrice, maxPrice, sort, page, pageSize).
// Se deja /products intacto porque otras pantallas (carrito, admin, buscador) esperan el arreglo completo.
app.get("/products/catalog", async (req, res) => {
  try {
    const params = parseCatalogParams(req.query);
    const { countSql, countValues, listSql, listValues } = buildCatalogQuery(params);
    const [countResult, listResult] = await Promise.all([
      pool.query(countSql, countValues),
      pool.query(listSql, listValues),
    ]);
    const total = countResult.rows[0]?.total ?? 0;
    const items = listResult.rows.map((p) => ({
      ...p,
      notes: { salida: p.salida, corazon: p.corazon, fondo: p.fondo },
    }));
    res.json({
      items,
      total,
      page: params.page,
      pageSize: params.pageSize,
      totalPages: Math.max(1, Math.ceil(total / params.pageSize)),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error al obtener el catálogo" });
  }
});

// SFTWRKEY-424: marcas disponibles para el filtro del catálogo
app.get("/products/brands", async (_req, res) => {
  try {
    const result = await pool.query(
      `SELECT DISTINCT brand FROM products
       WHERE stock > 0 AND brand IS NOT NULL AND brand <> ''
       ORDER BY brand ASC`
    );
    res.json({ brands: result.rows.map((r) => r.brand) });
  } catch (err) {
    res.status(500).json({ message: "Error al obtener marcas" });
  }
});

// SFTWRKEY-275: Listar categorías disponibles (para poblar el filtro en el frontend)
app.get("/categories", async (req, res) => {
  try {
    const result = await pool.query('SELECT id, nombre FROM categories ORDER BY nombre ASC');
    res.json({ success: true, categories: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error al obtener categorías" });
  }
});


// buscar productos
app.get("/products/search", async (req, res) => {
  const { busqueda } = req.query;

  if (!busqueda || !busqueda.trim()) {
    return res.status(400).json({
      success: false,
      message: "Parámetro de búsqueda requerido."
    });
  }

  try {
    const result = await pool.query(
      `SELECT p.*, c.nombre AS category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.stock > 0
         AND (
           p.name ILIKE $1
           OR p.description ILIKE $1
           OR p.salida ILIKE $1
           OR p.corazon ILIKE $1
           OR p.fondo ILIKE $1
         )
       ORDER BY p.created_at DESC`,
      [`%${busqueda}%`]
    );

    const formatted = result.rows.map(p => ({
      ...p,
      notes: {
        salida: p.salida,
        corazon: p.corazon,
        fondo: p.fondo
      }
    }));

    res.json({
      success: true,
      products: formatted
    });

  } catch (err) {
    console.error(err);

    res.status(500).json({
      success: false,
      message: "Error en búsqueda de productos."
    });
  }
});

app.get("/products/:id", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, c.nombre AS category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: "Producto no encontrado" });
    const p = result.rows[0];
    res.json({
      ...p,
      notes: { salida: p.salida, corazon: p.corazon, fondo: p.fondo }
    });
  } catch (err) {
    res.status(500).json({ message: "Error al obtener producto" });
  }
});

const PRODUCT_ID_REGEX = /^[a-z0-9]+(?:-[a-z0-9]+)*$/i;
const PRICE_REGEX = /^\d+(?:\.\d{1,2})?$/;
const STOCK_REGEX = /^\d+$/;

function validateProductPayload(body, { requireId }) {
  const { id, name, price, stock, notes, category_id } = body ?? {};

  if (requireId && (!id || typeof id !== "string" || !PRODUCT_ID_REGEX.test(id.trim()))) {
    return "El id es obligatorio y solo puede tener letras, números y guiones.";
  }
  if (!name || typeof name !== "string" || !name.trim() || name.length > 200) {
    return "El nombre es obligatorio y debe tener hasta 200 caracteres.";
  }
  if (price === undefined || price === null || !PRICE_REGEX.test(String(price))) {
    return "El precio debe ser un número no negativo con hasta dos decimales.";
  }
  if (stock !== undefined && stock !== null && !STOCK_REGEX.test(String(stock))) {
    return "El stock debe ser un número entero no negativo.";
  }
  if (category_id !== undefined && category_id !== null && !Number.isInteger(Number(category_id))) {
    return "category_id debe ser un número entero.";
  }
  if (notes !== undefined && notes !== null && (typeof notes !== "object" || Array.isArray(notes))) {
    return "notes debe ser un objeto con salida, corazon y fondo.";
  }
  if (!isSafeImage(body?.image)) {
    return IMAGE_ERROR_MESSAGE;
  }
  return null;
}

app.post("/products", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const { id, name, price, image, description, stock, notes, category_id, brand, external_source, external_id, synced_at } = req.body;
  const validationError = validateProductPayload(req.body, { requireId: true });
  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }
  try {
    await pool.query(
      `INSERT INTO products (id, name, price, image, description, stock, salida, corazon, fondo, category_id, brand, external_source, external_id, synced_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
      [id, name, price, image, description, stock, notes?.salida, notes?.corazon, notes?.fondo, category_id || null, brand || null, external_source || null, external_id || null, synced_at || null]
    );
    res.status(201).json({ success: true, message: "Producto creado" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al crear producto" });
  }
});

app.put("/products/:id", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const { name, price, image, description, stock, notes, category_id, brand, external_source, external_id, synced_at } = req.body;
  // SFTWRKEY-379: el PUT usa la misma validación que el POST (antes aceptaba tipos y largos inválidos).
  const validationError = validateProductPayload(req.body, { requireId: false });
  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }
  try {
    const result = await pool.query(
      `UPDATE products
       SET name = $1, price = $2, image = $3, description = $4, stock = $5, salida = $6, corazon = $7, fondo = $8, category_id = $9, brand = $10, external_source = $11, external_id = $12, synced_at = $13
       WHERE id = $14`,
      [name, price, image, description, stock, notes?.salida, notes?.corazon, notes?.fondo, category_id || null, brand || null, external_source || null, external_id || null, synced_at || null, req.params.id]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: "Producto no encontrado" });
    }
    res.json({ success: true, message: "Producto actualizado" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al actualizar producto" });
  }
});

app.delete("/products/:id", authenticate, requireRoles("ADMIN"), async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM products WHERE id = $1', [req.params.id]);

    if (result.rowCount === 0) {
      return res.status(404).json({ success: false, message: "Producto no encontrado" });
    }
    res.json({ success: true, message: "Producto eliminado" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al eliminar producto" });
  }
});

// fragmento para la integracion PerfumAPI: busqueda para el admin
// compone cliente + marcas + mapper + validacion + log de errores
// sin restriccion por catalogo propio: el admin puede buscar cualquier perfume.
app.get("/external-perfumes/search", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const { q, brand } = req.query;
  if (!q || !q.trim()) {
    return res.status(400).json({ success: false, message: "Parámetro de búsqueda 'q' requerido." });
  }

  try {
    const raw = await searchExternalPerfumes(q, 30);
    const filtered = brand && brand.trim()
      ? raw.filter((p) => (p.brand || '').toLowerCase() === brand.trim().toLowerCase())
      : raw;

    const results = [];
    for (const item of filtered) {
      const mapped = mapExternalPerfumeToProduct(item);
      const { ok, candidate, warnings } = validateMappedPerfume(mapped);
      if (!ok) {
        await logSyncError({ query: q, externalId: item.id, errorMessage: warnings.join('; ') });
        continue;
      }
      results.push({ ...candidate, warnings });
    }

    res.json({ success: true, results });
  } catch (err) {
    console.error(err);
    const message = err instanceof PerfumApiError ? err.message : 'No se pudo consultar PerfumAPI.';
    await logSyncError({ query: q, errorMessage: message });
    res.status(502).json({ success: false, message });
  }
});

// marcas conocidas por PerfumAPI, para un filtro opcional en el buscador del admin
app.get("/external-perfumes/brands", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const brands = await getKnownBrands();
    res.json({ success: true, brands });
  } catch (err) {
    console.error(err);
    const message = err instanceof PerfumApiError ? err.message : 'No se pudo consultar las marcas de PerfumAPI.';
    await logSyncError({ errorMessage: message });
    res.status(502).json({ success: false, message });
  }
});

// integracion PerfumAPI: historial de errores de sincronizacion
app.get("/admin/perfum-sync-logs", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const logs = await listSyncLogs();
    res.json({ success: true, logs });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "No se pudo consultar el historial de errores de PerfumAPI." });
  }
});

// SFTWRKEY-277..282: formato, lectura, validación, importación e historial CSV.
app.get("/imports/products/template", authenticate, requireRoles("ADMIN"), (_req, res) => {
  res.type("text/csv").attachment("plantilla-perfumes.csv").send(CSV_TEMPLATE);
});

app.get("/imports/products", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    await ensureImportHistoryTable();
    const result = await pool.query(
      `SELECT id, file_name, total_rows, imported_rows, rejected_rows, errors, created_at
       FROM product_imports ORDER BY created_at DESC, id DESC LIMIT 50`
    );
    res.json({ success: true, imports: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "No se pudo consultar el historial de importaciones." });
  }
});

app.post("/imports/products", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const { fileName = "importacion.csv", csv } = req.body ?? {};
  if (typeof fileName !== "string" || !fileName.toLowerCase().endsWith(".csv")) {
    return res.status(400).json({ success: false, message: "Debe seleccionar un archivo con extensión .csv." });
  }
  try {
    const parsed = validateCsv(csv);
    const errors = [...parsed.errors];
    const ids = parsed.products.map((product) => product.id);
    const existing = await pool.query("SELECT id FROM products WHERE id = ANY($1::varchar[])", [ids]);
    const existingIds = new Set(existing.rows.map((product) => product.id.toLowerCase()));
    parsed.products.forEach((product) => {
      if (existingIds.has(product.id.toLowerCase())) {
        errors.push({ row: product.row, field: "id", message: "Ya existe un perfume con este identificador." });
      }
    });
    const rejectedRows = new Set(errors.map((error) => error.row));
    const validProducts = parsed.products.filter((product) => !rejectedRows.has(product.row));

    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      for (const product of validProducts) {
        await client.query(
          `INSERT INTO products (id, name, price, image, description, stock, salida, corazon, fondo)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
          [product.id, product.name, product.price, product.image || null, product.description || null,
            product.stock, product.salida || null, product.corazon || null, product.fondo || null]
        );
      }
      await client.query("COMMIT");
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
    const history = await saveImportHistory({ fileName: fileName.slice(0, 255), totalRows: parsed.totalRows, importedRows: validProducts.length, errors });
    res.status(201).json({ success: true, message: "Importación procesada.", summary: history });
  } catch (err) {
    if (err instanceof CsvValidationError) {
      return res.status(400).json({ success: false, message: err.message });
    }
    console.error(err);
    res.status(500).json({ success: false, message: "No se pudo procesar el archivo CSV." });
  }
});

app.get("/", (req, res) => res.send("Backend Luxor funcionando"));

// ── Auth ──────────────────────────────────────────────────────────────────────
// SFTWRKEY-401: guardar logins fallidos y bloqueos
const onLoginFailed = ({ email, req }) =>
  recordSecurityEvent({ type: SECURITY_EVENT_TYPES.LOGIN_FAILED, ip: req.ip, email, path: req.path });
const onRateLimitBlock = (req) =>
  recordSecurityEvent({ type: SECURITY_EVENT_TYPES.RATE_LIMITED, ip: req.ip, path: req.path });

app.post("/login", rateLimit({ windowMs: 60_000, max: 10, onBlock: onRateLimitBlock }), createLoginHandler({ pool, bcrypt, signToken, onLoginFailed }));

// SFTWRKEY-220 + SFTWRKEY-223: Register con validación de campos y email duplicado
// SFTWRKEY-408: máximo 6 registros por hora por IP (evita cuentas masivas y averiguar
// correos registrados con el 409); el bloqueo queda como evento de seguridad.
app.post("/register", rateLimit({ windowMs: 60 * 60_000, max: 6, onBlock: onRateLimitBlock }), createRegisterHandler({ pool, bcrypt, saltRounds: SALT_ROUNDS }));

// ── Usuario ───────────────────────────────────────────────────────────────────
app.get("/user/:userId", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.name, u.email, r.nombre AS role
       FROM users u JOIN rol r ON u.role = r.id_rol
       WHERE u.id = $1`,
      [req.params.userId]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: "Usuario no encontrado" });
    res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error al obtener usuario" });
  }
});

// SFTWRKEY-323/324/325: Historial real de pedidos
app.get("/user/:userId/orders", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  try {
    const ordersResult = await pool.query(
      `SELECT id, total, status, created_at
       FROM orders
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [req.params.userId]
    );

    // SFTWRKEY-420: productos e historial de todos los pedidos en dos consultas
    // (antes era una consulta por cada pedido)
    const ids = ordersResult.rows.map((order) => order.id);
    let items = [];
    let history = [];
    if (ids.length > 0) {
      const itemsResult = await pool.query(
        `SELECT oi.order_id, oi.product_id, oi.quantity, oi.unit_price, p.name, p.image
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.order_id = ANY($1::int[])
         ORDER BY oi.id`,
        [ids]
      );
      const historyResult = await pool.query(
        `SELECT order_id, from_status, to_status, changed_at
         FROM order_status_history
         WHERE order_id = ANY($1::int[])
         ORDER BY changed_at, id`,
        [ids]
      );
      items = itemsResult.rows;
      history = historyResult.rows;
    }

    const orders = ordersResult.rows.map((order) => ({
      ...order,
      items: items
        .filter((item) => item.order_id === order.id)
        .map(({ order_id, ...item }) => ({ ...item, name: item.name ?? item.product_id })),
      history: history
        .filter((h) => h.order_id === order.id)
        .map(({ order_id, ...h }) => h),
    }));

    // sin cache: si el admin cambia el estado, el cliente lo ve al recargar
    res.set("Cache-Control", "no-store").json({ success: true, orders });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener el historial de pedidos" });
  }
});

// SFTWRKEY-321: Editar información personal
app.put("/user/:userId", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) {
    return res.status(400).json({ success: false, message: "Nombre y correo son requeridos." });
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: "El formato del correo no es válido." });
  }
  try {
    const result = await pool.query(
      `UPDATE users SET name = $1, email = $2 WHERE id = $3
       RETURNING id, name, email`,
      [name, email, req.params.userId]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Usuario no encontrado." });
    }
    res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ success: false, message: "Ese correo ya está en uso por otra cuenta." });
    }
    console.error(err);
    res.status(500).json({ success: false, message: "Error al actualizar la información." });
  }
});

// SFTWRKEY-322: Cambiar contraseña
app.put("/user/:userId/password", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), rateLimit({ windowMs: 60_000, max: 10, onBlock: onRateLimitBlock }), async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ success: false, message: "Debes ingresar la contraseña actual y la nueva." });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ success: false, message: "La nueva contraseña debe tener al menos 6 caracteres." });
  }
  try {
    const userResult = await pool.query('SELECT password FROM users WHERE id = $1', [req.params.userId]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Usuario no encontrado." });
    }
    const match = await bcrypt.compare(currentPassword, userResult.rows[0].password);
    if (!match) {
      return res.status(401).json({ success: false, message: "La contraseña actual es incorrecta." });
    }
    const newHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await pool.query('UPDATE users SET password = $1 WHERE id = $2', [newHash, req.params.userId]);
    res.json({ success: true, message: "Contraseña actualizada correctamente." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al cambiar la contraseña." });
  }
});

// SFTWRKEY-215: Búsqueda de usuarios con ILIKE (case-insensitive)
app.get("/users/search", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const { q } = req.query;
  if (!q) return res.status(400).json({ success: false, message: "Parámetro de búsqueda requerido." });
  try {
    const result = await pool.query(
      `SELECT u.id, u.name, u.email, r.nombre AS role
       FROM users u JOIN rol r ON u.role = r.id_rol
       WHERE u.name ILIKE $1 OR u.email ILIKE $1
       ORDER BY u.name ASC`,
      [`%${q}%`]
    );
    res.json({ success: true, users: result.rows });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error en búsqueda." });
  }
});

// ── Carrito ───────────────────────────────────────────────────────────────────
app.get("/cart/:userId", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  try {
    const cartResult = await pool.query('SELECT id FROM carts WHERE user_id = $1', [req.params.userId]);
    if (cartResult.rows.length === 0) return res.json([]);
    const items = await pool.query('SELECT product_id, quantity FROM cart_items WHERE cart_id = $1', [cartResult.rows[0].id]);
    res.json(items.rows);
  } catch (err) {
    res.status(500).json({ message: "Error" });
  }
});

const MAX_QTY_PER_ITEM = 10;

function validateCartItems(items) {
  if (!Array.isArray(items)) {
    return "El body debe ser un arreglo de items del carrito.";
  }
  for (const item of items) {
    if (!item || typeof item !== "object" || Array.isArray(item)) {
      return "Cada item del carrito debe ser un objeto con product_id y quantity.";
    }
    if (!item.product_id || typeof item.product_id !== "string") {
      return "Cada item debe traer un product_id válido.";
    }
    if (!Number.isInteger(item.quantity) || item.quantity <= 0) {
      return "La cantidad de cada item debe ser un entero mayor a 0.";
    }
    // SFTWRKEY-391: mismo tope que el selector de cantidad del frontend (MAX_QTY_PER_ITEM).
    if (item.quantity > MAX_QTY_PER_ITEM) {
      return `La cantidad máxima por producto es ${MAX_QTY_PER_ITEM}.`;
    }
  }
  return null;
}

app.post("/cart/:userId", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  const userId = req.params.userId;
  const items = req.body;
  const validationError = validateCartItems(items);
  if (validationError) {
    return res.status(400).json({ success: false, message: validationError });
  }
  
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let cartResult = await client.query('SELECT id FROM carts WHERE user_id = $1', [userId]);
    if (cartResult.rows.length === 0)
      cartResult = await client.query('INSERT INTO carts (user_id) VALUES ($1) RETURNING id', [userId]);
    const cartId = cartResult.rows[0].id;
    await client.query('DELETE FROM cart_items WHERE cart_id = $1', [cartId]);
    for (const item of items) {
      await client.query('INSERT INTO cart_items (cart_id, product_id, quantity) VALUES ($1, $2, $3)', [cartId, item.product_id, item.quantity]);
    }
    await client.query('COMMIT');
    res.json({ success: true });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error("Error al sincronizar carrito:", err);
    res.status(500).json({ message: "Error" });
  } finally {
    client.release();
  }
});

// ── Reportes ──────────────────────────────────────────────────────────────────
app.get("/report", authenticate, requireRoles("ADMIN"), async (req, res) => {
  try {
    const users = await pool.query('SELECT COUNT(*) as total FROM users');
    const items = await pool.query('SELECT SUM(quantity) as total FROM cart_items');
    const top = await pool.query(`SELECT oi.product_id, SUM(oi.quantity) as total_quantity
        FROM order_items oi
        JOIN orders o ON o.id = oi.order_id AND o.status <> 'cancelado'
        GROUP BY oi.product_id
        ORDER BY total_quantity DESC
        LIMIT 5`);
    res.json({ success: true, data: { totalUsers: parseInt(users.rows[0].total), totalItemsInCarts: parseInt(items.rows[0].total) || 0, topProducts: top.rows } });
  } catch (err) {
    res.status(500).json({ success: false });
  }
});


// métricas generales del
app.get("/report/metrics", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const metrics = await getGeneralMetrics();
    res.json({ success: true, metrics });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener las métricas generales." });
  }
});

//ventas por mes ultimos 12
app.get("/report/sales-monthly", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const months = Number(req.query.months ?? 12);
  if (!Number.isInteger(months) || months < 1 || months > 36) {
    return res.status(400).json({ success: false, message: "El parámetro 'months' debe ser un entero entre 1 y 36." });
  }
  try {
    const sales = await getMonthlySales(months);
    res.json({ success: true, sales });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener las ventas mensuales." });
  }
});

// ventas por categoría (no existía ningún endpoint con este dato)
app.get("/report/sales-by-category", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const sales = await getSalesByCategory();
    res.json({ success: true, sales });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener las ventas por categoría." });
  }
});

// productos más vendidos
app.get("/report/top-products", authenticate, requireRoles("ADMIN"), async (req, res) => {
  const limit = Number(req.query.limit ?? 5);
  if (!Number.isInteger(limit) || limit < 1 || limit > 50) {
    return res.status(400).json({ success: false, message: "El parámetro 'limit' debe ser un entero entre 1 y 50." });
  }
  try {
    const products = await getTopProducts(limit);
    res.json({ success: true, products });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener los productos más vendidos." });
  }
});

// inventario por categoría
app.get("/report/inventory", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const inventory = await getInventoryByCategory();
    res.json({ success: true, inventory });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Error al obtener el inventario por categoría." });
  }
});

// alertas de seguridad del panel admin
app.get("/admin/security-alerts", authenticate, requireRoles("ADMIN"), async (_req, res) => {
  try {
    const data = await getSecurityAlerts();
    res.set("Cache-Control", "no-store").json({ success: true, ...data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "No se pudieron obtener las alertas de seguridad." });
  }
});

// ── Checkout / Pagos ─────────────────────────────────────────────────────────
const ensurePaymentsTable = () => pool.query(`
  CREATE TABLE IF NOT EXISTS payments (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id) ON DELETE SET NULL,
    user_id INTEGER NOT NULL REFERENCES users(id),
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'GTQ',
    status VARCHAR(20) NOT NULL,
    gateway_reference VARCHAR(100),
    auth_code VARCHAR(20),
    card_brand VARCHAR(20),
    card_last4 VARCHAR(4),
    decline_code VARCHAR(50),
    decline_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
  )
`);

const savePaymentRecord = async ({ orderId, userId, amount, status, gatewayResult }) => {
  await ensurePaymentsTable();
  const result = await pool.query(
    `INSERT INTO payments
       (order_id, user_id, amount, status, gateway_reference, auth_code, card_brand, card_last4, decline_code, decline_message)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     RETURNING id, order_id, status, card_brand, card_last4, created_at`,
    [
      orderId,
      userId,
      amount,
      status,
      gatewayResult.transactionId,
      gatewayResult.authCode,
      gatewayResult.brand,
      gatewayResult.last4,
      gatewayResult.declineCode,
      gatewayResult.declineMessage,
    ]
  );
  return result.rows[0];
};

const CARD_FIELDS = ["cardholderName", "cardNumber", "expiryMonth", "expiryYear", "cvv", "billingAddress", "city", "postalCode", "country"];

function validateCardPayload(body) {
  for (const field of CARD_FIELDS) {
    if (!body?.[field] || !String(body[field]).trim()) {
      return `El campo '${field}' es requerido para procesar el pago.`;
    }
  }
  const digits = String(body.cardNumber).replace(/\D/g, "");
  if (digits.length !== 16) return "El número de tarjeta debe tener 16 dígitos.";
  if (!/^\d{3}$/.test(body.cvv)) return "El CVV debe tener exactamente 3 dígitos.";
  return null;
}

// SFTWRKEY-295: Crear endpoint para pagos
// SFTWRKEY-296: Enviar información del carrito (a la pasarela)
// SFTWRKEY-297: Procesar respuesta de la pasarela
// SFTWRKEY-298: Mostrar confirmación de compra (datos que consume el frontend)
// SFTWRKEY-299: Registrar pago en base de datos
// SFTWRKEY-300: Manejo de pagos rechazados
app.post("/checkout/:userId", authenticate, authorizeSelfOrRoles("userId", "ADMIN"), async (req, res) => {
  const { userId } = req.params;
  const cardPayload = req.body ?? {};

  const validationError = validateCardPayload(cardPayload);
  if (validationError) {
    return res.status(400).json({ success: false, code: "INVALID_PAYMENT_DATA", message: validationError });
  }

  const client = await pool.connect();

  try {
    await ensurePaymentsTable();
    const cartResult = await client.query('SELECT id FROM carts WHERE user_id = $1', [userId]);
    if (cartResult.rows.length === 0) {
      return res.status(400).json({ success: false, code: "EMPTY_CART", message: "Tu carrito está vacío." });
    }
    const cartId = cartResult.rows[0].id;

    const itemsResult = await client.query(
      `SELECT ci.product_id, ci.quantity, p.name, p.price, p.stock
       FROM cart_items ci
       JOIN products p ON ci.product_id = p.id
       WHERE ci.cart_id = $1`,
      [cartId]
    );

    if (itemsResult.rows.length === 0) {
      return res.status(400).json({ success: false, code: "EMPTY_CART", message: "Tu carrito está vacío." });
    }

    const sinStock = itemsResult.rows.filter(item => item.quantity > item.stock);
    if (sinStock.length > 0) {
      return res.status(409).json({
        success: false,
        code: "INSUFFICIENT_STOCK",
        message: "Algunos productos ya no tienen stock suficiente.",
        items: sinStock.map(i => ({ product_id: i.product_id, name: i.name, disponible: i.stock, solicitado: i.quantity }))
      });
    }

    const total = itemsResult.rows.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
    // Recalculado a partir de p.price en la consulta anterior: el monto nunca se confía del cliente.

    // SFTWRKEY-296: se arma el payload con el detalle del carrito y se envía a la pasarela
    const gatewayPayload = buildGatewayPayload({
      orderReference: `user-${userId}-${Date.now()}`,
      amount: total,
      cartItems: itemsResult.rows,
      card: cardPayload,
      billing: cardPayload,
    });

    // SFTWRKEY-297: se procesa la respuesta de la pasarela (aprobado o rechazado)
    const gatewayResult = await chargeCard(gatewayPayload);

    if (!gatewayResult.approved) {
      // SFTWRKEY-300: manejo de pagos rechazados — se registra el intento fallido
      // (sin crear orden ni tocar el stock) y se informa el motivo al frontend.
      const payment = await savePaymentRecord({
        orderId: null,
        userId,
        amount: total,
        status: "rechazado",
        gatewayResult,
      });
      return res.status(402).json({
        success: false,
        code: "CARD_DECLINED",
        message: gatewayResult.declineMessage,
        declineCode: gatewayResult.declineCode,
        payment: { id: payment.id, status: payment.status },
      });
    }

    await client.query('BEGIN');

    // Se vuelve a verificar y bloquear el stock dentro de la transacción para evitar
    // que dos checkouts concurrentes sobrevendan el mismo producto.
    for (const item of itemsResult.rows) {
      const stockResult = await client.query(
        `UPDATE products SET stock = stock - $1 WHERE id = $2 AND stock >= $1 RETURNING id`,
        [item.quantity, item.product_id]
      );
      if (stockResult.rows.length === 0) {
        throw Object.assign(new Error("Stock insuficiente al confirmar el pago."), { code: "INSUFFICIENT_STOCK" });
      }
    }

    // SFTWRKEY-417: el pedido nace como 'pagado' y queda la primera fila del historial
    const orderResult = await client.query(
      `INSERT INTO orders (user_id, total, status) VALUES ($1, $2, 'pagado') RETURNING id, created_at`,
      [userId, total]
    );
    const orderId = orderResult.rows[0].id;
    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status) VALUES ($1, NULL, 'pagado')`,
      [orderId]
    );

    for (const item of itemsResult.rows) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES ($1, $2, $3, $4)`,
        [orderId, item.product_id, item.quantity, item.price]
      );
    }

    await client.query('DELETE FROM cart_items WHERE cart_id = $1', [cartId]);

    // SFTWRKEY-299: Registrar pago en base de datos, dentro de la misma transacción
    // que la orden — si esto falla, el ROLLBACK revierte también la orden y el stock.
    const paymentInsert = await client.query(
      `INSERT INTO payments
         (order_id, user_id, amount, status, gateway_reference, auth_code, card_brand, card_last4, decline_code, decline_message)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING id, order_id, status, card_brand, card_last4, created_at`,
      [
        orderId, userId, total, "aprobado",
        gatewayResult.transactionId, gatewayResult.authCode, gatewayResult.brand,
        gatewayResult.last4, gatewayResult.declineCode, gatewayResult.declineMessage,
      ]
    );
    const payment = paymentInsert.rows[0];

    await client.query('COMMIT');

    // SFTWRKEY-447: correo de confirmación; no frena la respuesta ni la compra si falla
    void notifyOrderStatus(pool, orderId, 'pagado');

    // SFTWRKEY-298: datos que la página de confirmación necesita mostrar
    return res.status(201).json({
      success: true,
      message: "Compra realizada con éxito.",
      order: { id: orderId, total, created_at: orderResult.rows[0].created_at },
      payment: {
        id: payment.id,
        status: payment.status,
        brand: gatewayResult.brand,
        last4: gatewayResult.last4,
        authCode: gatewayResult.authCode,
      },
    });

  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error("Error en checkout:", err);
    if (err instanceof PaymentGatewayError) {
      return res.status(502).json({ success: false, code: err.code, message: "No se pudo contactar a la pasarela de pago. Intenta de nuevo." });
    }
    if (err.code === "INSUFFICIENT_STOCK") {
      return res.status(409).json({ success: false, code: "INSUFFICIENT_STOCK", message: "Algunos productos ya no tienen stock suficiente." });
    }
    return res.status(500).json({
      success: false,
      code: "PAYMENT_ERROR",
      message: "No se pudo procesar el pago. Intenta de nuevo."
    });
  } finally {
    client.release();
  }
});

// Historial de preguntas y respuestas del chatbot
// SFTWRKEY-293: Registrar consultas del chatbot
const ensureChatbotQueriesTable = () => pool.query(`
  CREATE TABLE IF NOT EXISTS chatbot_queries (
    id SERIAL PRIMARY KEY,
    query TEXT NOT NULL,
    response TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
  )
`);

// SFTWRKEY-380: solo el chatbot puede registrar consultas (cabecera X-Internal-Key).
app.post("/chatbot/queries", requireInternalKey, async (req, res) => {
    const { query, response } = req.body;

    if (!query || !query.trim()) {
      return res.status(400).json({
        success: false,
        message: "La consulta es requerida."
      });
    }

    try {
      await ensureChatbotQueriesTable();
      const result = await pool.query(
        `INSERT INTO chatbot_queries (query, response)
        VALUES ($1, $2)
        RETURNING id, query, response, created_at`,
        [query, response || null]
      );

      return res.status(201).json({
        success: true,
        query: result.rows[0]
      });

    } catch (err) {
      console.error("Error registrando consulta del chatbot:", err);

      return res.status(500).json({
        success: false,
        message: "No se pudo registrar la consulta."
      });
    }
});

// SFTWRKEY-417: rutas de pedidos del admin
app.use(ordersRouter);

// SFTWRKEY-428: recuperar contraseña (antes del router de commerce, que prepara tablas en cada petición)
app.use(passwordResetRouter);

// SFTWRKEY-429: lista de deseos
app.use(wishlistRouter);

// SFTWRKEY-430: productos relacionados
app.use(relatedRouter);

// SFTWRKEY-457: fotos de productos subidas desde el panel
app.use(productImagesRouter);

// SFTWRKEY-458: el chatbot consulta el estado de un pedido (número + correo)
app.use(orderLookupRouter);

// Checkout de invitado, login con Google y alertas del admin. Va al final porque su
// middleware prepara las tablas en cada petición que entra al router: así solo lo
// alcanzan las rutas que no atendió ninguna de las anteriores.
app.use(commerceRouter);

// SFTWRKEY-384: 404 en JSON (el 404 por defecto de Express es HTML y trae su propia CSP).
app.use((_req, res) => {
  res.status(404).json({ success: false, message: "Recurso no encontrado." });
});

// SFTWRKEY-380: manejador global de errores. Nunca devuelve mensajes internos ni el
// stack trace (sin él, Express los muestra cuando NODE_ENV no es "production").
app.use((err, _req, res, _next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ success: false, message: "El cuerpo de la solicitud no es un JSON válido." });
  }
  if (err.type === "entity.too.large") {
    return res.status(413).json({ success: false, message: "La solicitud es demasiado grande." });
  }
  console.error(err);
  res.status(500).json({ success: false, message: "Error interno del servidor." });
});

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));
}

export default app;